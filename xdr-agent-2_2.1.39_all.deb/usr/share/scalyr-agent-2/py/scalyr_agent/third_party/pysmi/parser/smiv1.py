from pysmi.parser.smi import parserFactory
from pysmi.parser.dialect import smiV1

# compatibility stub
SmiV1Parser = parserFactory(**smiV1)

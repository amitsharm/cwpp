class AbstractLexer(object):
    def reset(self):
        raise NotImplementedError()

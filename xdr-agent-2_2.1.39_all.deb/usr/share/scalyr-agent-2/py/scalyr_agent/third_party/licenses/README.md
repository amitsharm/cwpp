# Third Party Licenses

We have included in this directory all third party licenses that are required to be redistributed with
the Scalyr Agent package.  These are licenses from software packages that are either included in the
Scalyr Agent distribution or were used to generate the distribution.  Some of these licenses only apply
to certain platform's packages, such as those only required for the Windows build.
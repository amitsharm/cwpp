# Obsolete, compatibility interface
from pysnmp.carrier.asyncore.dgram.unix import *

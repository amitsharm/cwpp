# Obsolete, compatibility interface
from pysnmp.carrier.asyncore.dispatch import *

AsynsockDispatcher = AsyncoreDispatcher
